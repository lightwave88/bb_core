const $util = require('util');

const $fs = require('fs');
const $url = require('url');
const $path = require('path');
const $url_query = require('querystring');

let $GM;
let $tools;
////////////////////////////////////////////////////////////////////////////////
class Server {
	$root;
	$headers = {};
	$options = {};
	//--------------------------------------
	constructor(options = {}) {

		let {
			root,
			header = null
		} = options;

		this.$root = $path.resolve(root || '.');
		this.$root = $path.normalize(this.$root);
		// 求得絕對路徑
		this.$root = $path.resolve(this.$root);

		if (header != null) {
			Object.assign(this.$headers, header);
		}
	}
	//--------------------------------------
	// start here
	createRequest(req, res) {
		const r = new Request(req, res, this);
		r.start();
	}
}
////////////////////////////////////////////////////////////////////////////////

class Request {
	parent;

	req;
	res;
	url;
	query;

	root;

	headers = {};

	html_content = '';

	post = {};
	get = {};

	options = {};

	method;
	//--------------------------------------
	// root 根目錄
	constructor(req, res, parent) {

		this.parent = parent;

		this.req = req;
		this.res = res;


		this._init();
	}
	//--------------------------------------
	_init() {
		const $parent = this.parent;

		Object.assign(this.headers, $parent.$header);

		Object.assign(this.options, $parent.$options);

		this.root = $parent.$root;
		//------------------
		let url = this.req.url;
		let o = $url.parse(url);
		this.query = o.query;

		try {
			this.url = decodeURI(o.pathname);
		} catch (e) {
			this._finish(400);
		}

		this.url = $path.normalize(this.url);

		let getData = $url_query.parse(this.query);
		Object.assign(this.get, getData)

		this.method = this.req.method;
	}
	//--------------------------------------
	// API
	// 從這裏開始
	start() {
		if (/^post$/i.test(this.method)) {
			let postBody = "";

			// post
			this.req.on('data', (chunk) => {
				postBody += chunk;

				if (postBody.length > 1e6) {
					this.req.connection.destroy();
				}
			});

			this.req.on('end', () => {
				// debugger;
				this._initPost(postBody);
				this._serveUrl(this.url);
			});
			return;
		} else {
			this._serveUrl(this.url);
		}
	}
	//--------------------------------------
	// url 轉 path
	_serveUrl(url) {
		let pathname = $path.join(this.root, url);
		this._servePath(pathname);
	}
	//--------------------------------------
	// 處理檔案
	// pathname 指定路徑
	// url 由網址解析路徑
	_servePath(pathname) {

		pathname = $path.normalize(pathname);

		// 取得要求檔案的資訊
		let pr = $tools.fileStat(pathname);
		//------------------

		pr.then((stat) => {
			if (stat.isFile()) {
				// 網址有相應的檔案
				// Stream a single file.
				this._respondFile(pathname, stat);
			} else if (stat.isDirectory()) {
				// 網址是目錄
				// Stream a directory of files.
				this._serveDir(pathname);
			}
		}, (er) => {
			// 網址沒有檔案
			console.log(er);
			this._finish(400);
		});
	}
	//--------------------------------------
	// 結束
	_finish(status, st) {
		// debugger;
		let headers = this.headers;

		this.res.writeHead(status, headers);

		if (st != null) {
			st.pipe(this.res);
		} else {
			this.res.end(this.html_content);
		}
	}
	//--------------------------------------
	// 若網址指向目錄
	_serveDir(dirpath) {
		// debugger;

		let dirList = [];
		let fileList = [];

		let prevUrl = getPreUrl(this.url);
		if (prevUrl != null) {
			dirList.push({
				fileName: '..',
				url: prevUrl,
				dir: true
			});
		}

		let p = (async () => {

			let files = await (new Promise(($res, $rej) => {
				// 讀取目錄下的結構
				$fs.readdir(dirpath, (er, _res) => {
					if (er) {
						$rej(er);
						return;
					}
					$res(_res);
				});
			}));
			//-----------------------

			// 取得檔案資訊
			for (let i = 0, fileName; i < files.length; i++) {
				// debugger;

				fileName = files[i];

				// fileName = encodeURIComponent(fileName);

				let file = $path.join(this.root, this.url, fileName);
				console.log('file => %s', file);

				let stat = await $tools.fileStat(file);

				// debugger;
				let _url;

				if (stat.isFile()) {

					let urlName = encodeURIComponent(fileName);
					_url = $path.join(this.url, urlName);

					fileList.push({
						url: _url,
						fileName,
						dir: false
					});
				} else if (stat.isDirectory()) {

					let urlName = encodeURIComponent(fileName);
					_url = $path.join(this.url, urlName);

					dirList.push({
						url: _url,
						fileName,
						dir: true
					});
				}
			}

			this.html_content = formatContent(dirList, fileList);
		})();
		//----------------------------

		p.then(() => {
			// debugger;

			// headers['Date'] = (new Date()).toUTCString();
			this.headers['Content-Type'] = 'text/html;charset=utf-8';

			this._finish(200);
		}, (er) => {
			// debugger;
			console.log(er);
			this._finish(400);
		});
	}
	//--------------------------------------
	// 針對檔案顯示
	// stat: 檔案資訊
	_respondFile(pathname, stat) {
		// debugger;
		const $mime = $GM.get('mime');

		const headers = this.headers;
		let filename = $path.basename(pathname);
		// 副檔名
		const extname = getFileExtname(pathname);

		let contentType = $mime.contentType(filename);

		let mtime = Date.parse(stat.mtime);

		let clientETag = this.req.headers['if-none-match'];
		let clientMTime = Date.parse(this.req.headers['if-modified-since']);
		let startByte = 0;
		let length = stat.size;
		let byteRange = parseByteRange(this.req, stat);

		/* Handle byte ranges */
		if (byteRange.valid) {
			if (byteRange.to < length) {

				// Note: HTTP Range param is inclusive
				startByte = byteRange.from;
				length = byteRange.to - byteRange.from + 1;
				status = 206;

				// Set Content-Range response header (we advertise initial resource size on server here (stat.size))
				headers['Content-Range'] = 'bytes ' + byteRange.from + '-' + byteRange.to + '/' + stat.size;

			} else {
				byteRange.valid = false;
				console.warn("Range request exceeds file boundaries, goes until byte no", byteRange.to,
					"against file size of",
					length, "bytes");
			}
		}

		/* In any case, check for unhandled byte range headers */
		if (!byteRange.valid && this.req.headers['range']) {
			console.error(new Error("Range request present but invalid, might serve whole file instead"));
		}

		headers['Etag'] = JSON.stringify([stat.ino, stat.size, mtime].join('-'));
		headers['Date'] = new(Date)().toUTCString();
		headers['Last-Modified'] = new(Date)(stat.mtime).toUTCString();
		headers['Content-Type'] = contentType;
		headers['Content-Length'] = length;

		// Conditional GET
		// If the "If-Modified-Since" or "If-None-Match" headers
		// match the conditions, send a 304 Not Modified.
		if ((clientMTime || clientETag) &&
			(!clientETag || clientETag === headers['Etag']) &&
			(!clientMTime || clientMTime >= mtime)) {
			// 304 response should not contain entity headers
			['Content-Encoding',
				'Content-Language',
				'Content-Length',
				'Content-Location',
				'Content-MD5',
				'Content-Range',
				'Content-Type',
				'Expires',
				'Last-Modified'
			].forEach((entityHeader) => {
				delete headers[entityHeader];
			});

			this._finish(304);
		} else {
			// debugger;

			let st = this._stream(pathname, length, startByte);
			this._finish(200, st);

		}
	}
	//--------------------------------------
	_readFile(pathname) {
		console.log('readFile');

		const $mime = $GM.get('mime');

		const def = $tools.deferred();

		const extname = getFileExtname(pathname);

		let mimeType = $mime.lookup(extname);
		let encode = $mime.charset(mimeType);

		$fs.readFile(pathname, encode, (er, data) => {
			if (er != null) {
				def.reject(er);
				return;
			}
			def.resolve(data);
		});

		return def.promise;
	}

	//--------------------------------------
	_stream(pathname, length, startByte) {
		console.log('stram');

		const $mime = $GM.get('mime');

		// Stream the file to the client
		const st = $fs.createReadStream(pathname, {
			flags: 'r',
			// mode: 0666,
			start: startByte,
			end: startByte + (length ? length - 1 : 0)
		});

		const extname = getFileExtname(pathname);

		let mimeType = $mime.lookup(extname);
		let encode = $mime.charset(mimeType);

		if (encode != null) {
			st.setEncoding(encode);
		}

		return st;
	}
	//--------------------------------------
	// 編譯模板
	_templateCompile(text) {
		debugger;

		const $ejs = $GM['ejs'];

		let global = {
			"$_GET": (this.get),
			"$_POST": (this.post),
			"$_REQUEST": {},
			"$_COOKIE": this._initCookie(),
			"$require": $require,
			"$print": this._initPrint()
		};

		function env($text, $global, $ejs) {
			let res;
			try {
				res = $ejs.render($text, $global);
			} catch (error) {

				this.html_content = `
        <div>
          compile error
          <p>${error}</p>
        </div>`;
				this._finish(200);
			}
			return res;
		} // end
		let res = env.call(this, text, global, $ejs);

		return res;
	}
	//--------------------------------------
	_initPost(text) {

		if (!text.length) {
			return;
		}

		let pairs = text.split('&');

		pairs.forEach((value) => {
			let pair = value.split('=');
			let k = pair[0];
			let v = (pair[1] != null) ? pair[1] : '';
			this.post[k] = v;
		});
	}
	//------------------------------------------------
	_initPrint() {
		return function(value) {
			debugger;
			let res;
			if (value == null) {
				res = (value === null) ? "null" : "undefined";
			} else if (typeof value) {
				try {
					res = JSON.stringify(value);
				} catch (error) {
					res = value.toString();
				}
			} else {
				res = "" + value;
			}
			return res;
		};
	}
}
////////////////////////////////////////////////////////////////////////////////
function parseByteRange(req, stat) {
	var byteRange = {
		from: 0,
		to: 0,
		valid: false
	}

	var rangeHeader = req.headers['range'];
	var flavor = 'bytes=';

	if (rangeHeader) {
		if (rangeHeader.indexOf(flavor) == 0 && rangeHeader.indexOf(',') == -1) {
			/* Parse */
			rangeHeader = rangeHeader.substr(flavor.length).split('-');
			byteRange.from = parseInt(rangeHeader[0]);
			byteRange.to = parseInt(rangeHeader[1]);

			/* Replace empty fields of differential requests by absolute values */
			if (isNaN(byteRange.from) && !isNaN(byteRange.to)) {
				byteRange.from = stat.size - byteRange.to;
				byteRange.to = stat.size ? stat.size - 1 : 0;
			} else if (!isNaN(byteRange.from) && isNaN(byteRange.to)) {
				byteRange.to = stat.size ? stat.size - 1 : 0;
			}

			/* General byte range validation */
			if (!isNaN(byteRange.from) && !!byteRange.to && 0 <= byteRange.from && byteRange.from < byteRange.to) {
				byteRange.valid = true;
			} else {
				console.warn("Request contains invalid range header: ", rangeHeader);
			}
		} else {
			console.warn("Request contains unsupported range header: ", rangeHeader);
		}
	}
	return byteRange;
}
//--------------------------------------
// 取得上一層路徑
function getPreUrl(url) {
	console.log('url=%s', url);
	let _url = url.replace(/^[\\/]/, '');

	let res = null;

	if (_url.trim().length == 0) {
		return res;
	}

	let list = _url.split(/[\\/]/);

	list.pop();

	res = list.join('/');

	console.log(JSON.stringify(list));

	res = '/' + res;

	res = $path.normalize(res);
	return res;
}
//--------------------------------------
// 輸出檔案列表頁面的內容
function formatContent(dirList = [], fileList = []) {
	let content_list = [];

	dirList.forEach((d) => {
		let content = `<p class="dir">
              <a href="${d.url}">${d.fileName}</a>
          </p>`;
		content_list.push(content);
	});

	fileList.forEach((d) => {
		let content = `<p class="file">
              <a href="${d.url}">${d.fileName}</a>
          </p>`;
		content_list.push(content);
	});

	let content = content_list.join('\n');

	let template = `<style>
            p.dir {
                background-color: #FF0;
            }
            </style>
            <div>
              ${content}
            </div>`;

	return template;
}
//--------------------------------------
function getFileExtname(filename) {
	return $path.extname(filename).slice(1);
}
//--------------------------------------
// Exports
module.exports = function(gm) {
	$GM = gm;
	$tools = $GM.get('tools');
	return Server;
}
