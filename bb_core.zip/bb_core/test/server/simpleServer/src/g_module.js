const $modules = new Map();

// for node.js
const $g_moudle = {
  get path() {
    return __dirname;
  },
  //--------------------------------------
  load(name, module, inject = false) {
    // debugger;

    if (isPlaineObj(name)) {
      let list = name;
      Object.keys(name).forEach(name => {
        this.load(name, list[name]);
      });
      return;
    }
    //------------------
    // 針對批量的設定
    // {moduleName:[module, inject]}
    if (Array.isArray(module)) {
      let [_module, _inject = false] = module;
      module = _module;
      inject = _inject;
    }
    //------------------
    let m = require(module);
    if (typeof m == 'function' && inject === true) {
      m = m(this);
    }
    $modules.set(name, m);
  },
  //--------------------------------------
  get(name) {
    return ($modules.has(name) ? $modules.get(name) : null);
  },
  //--------------------------------------
  has(name) {
    return $modules.has(name);
  },
};


function isPlaineObj(data) {
  if (data == null) {
    return false;
  }
  if (typeof data != 'object') {
    return false;
  }
  if (data.constructor != {}.constructor) {
    return false;
  }
  return true;
}


module.exports = $g_moudle;
