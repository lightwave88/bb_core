const GM = require('./g_module.js');

let loadMap = {
  tools: './tools.js',
  mime: './mime/index.js',
  'Server': ['./static.js', true],
}

// 引入模組
GM.load(loadMap);

let Server = GM.get('Server');
let mime = GM.get('mime');

module.exports = {
  Server,
  mime
};
