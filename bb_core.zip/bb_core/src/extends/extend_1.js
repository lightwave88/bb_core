let $bb;
const $extend = {};
//------------------------------------------------------------------------------

{
	$extend.isEqualValue = isEqualValue;
	$extend.$isEqualValue = isEqualValue;
	//------------------
	function isEqualValue(data_1, data_2) {
		// debugger;
		const $checkList = [{
			0: data_1,
			1: data_2,
		}];

		let res = true;

		let i = 0;
		while (i < $checkList.length) {
			// debugger;
			let {
				0: data_1,
				1: data_2
			} = $checkList[i];

			let compare = new Compare(data_1, data_2);

			if (!compare.isEqual()) {
				res = false;
				break;
			}
			//-------------
			let childs = compare.getChilds();

			// debugger;
			if (childs != null) {
				while (childs.length > 0) {
					let child = childs.shift();
					$checkList.push(child);
				}
			}
			i++;
		} // while
		return res;
	}
	//----------------------------
	const $reg_1 = /^\[object Object\]$/;

	class Compare {
		$type;
		$childs;
		$data = {};
		$type = {};
		$isObject;
		//------------------
		constructor(data_1, data_2) {
			this.$data['0'] = data_1;
			this.$data['1'] = data_2;
		}
		//------------------
		isEqual() {
			// debugger;
			let {
				0: data_1,
				1: data_2,
			} = this.$data;
			//-------------
			if (!this._checkType()) {
				return false;
			}
			//-------------
			// debugger;
			// 確定是兩個是同 type
			if (!this._isObject()) {
				// 簡單數值相比
				if (!this._compareSimpleValue()) {
					return false;
				}
			} else {
				// 物件相比
				if (data_1 === data_2) {
					// 指向同個位址
				} else if (this._isContainer()) {
					// 是數據容器
					if (!this._compareContainer()) {
						return false;
					}
					this._checkChilds();
				} else {
					// 不是數據容器
					if (!this._compareObject()) {
						return false
					}
				}
			}
			return true;
		}
		//------------------
		getChilds() {
			return this.$childs;
		}
		//------------------
		_compareSimpleValue() {
			let {
				0: data_1,
				1: data_2,
			} = this.$data;

			let res;
			switch (this.$type) {
				case '[object String]':
					// 避免漢字
					// res = (data_1.localeCompare(data_2) == 0);
					res = (data_1 === data_2);
					break;
				default:
					res = (data_1 === data_2);
					break;
			} // switch
			return res;
		}
		//------------------
		_checkType() {
			// debugger;

			let {
				0: data_1,
				1: data_2,
			} = this.$data;

			let type_1 = this._getType(data_1);
			let type_2 = this._getType(data_2);

			if (type_1 != type_2) {
				return false;
			}
			//--------
			this.$type[0] = type_1;
			this.$type[1] = type_2;

			return true;
		}
		//------------------
		_getType(data) {
			// debugger;

			let type = this._toString(data);

			if ($reg_1.test(type) && $bb.isPlainObject(data)) {
				type += '{}'
			}
			return type;
		}
		//------------------
		_isObject() {
			let {
				0: data_1,
				1: data_2,
			} = this.$data;

			let res;
			if (data_1 == null) {
				res = false;
			} else {
				let type = typeof(data_1);
				switch (type) {
					case 'object':
					case 'symbol':
						res = true;
						break;
					default:
						res = false;
						break;
				}
			}
			return res;
		}
		//------------------
		_isContainer() {
			// debugger;
			let {
				0: type_1,
				1: type_2,
			} = this.$type;

			let res = false;
			switch (type_1) {
				case '[object Object]{}':
				case '[object Array]':
				case '[object Map]':
				case '[object Set]':
					res = true;
					break;
			}
			return res;
		}
		//------------------
		_compareContainer() {
			// debugger;

			let {
				0: data_1,
				1: data_2,
			} = this.$data;

			let {
				0: type_1,
				1: type_2,
			} = this.$type;

			let res;
			switch (type_1) {
				case '[object Object]{}': {
					let keys_1 = Object.keys(data_1);
					let keys_2 = Object.keys(data_2);

					if (keys_1.length != keys_2.length) {
						res = false;
					} else {
						keys_1 = new Set(keys_1);
						keys_2 = new Set(keys_2);

						for (let item of keys_1) {
							keys_2.delete(item);
						}

						if (keys_2.size > 0) {
							res = false;
						} else {
							res = true;
						}
					}
				}
				break;
				case '[object Array]':
					res = (data_1.length == data_2.length);
					break
				case '[object Map]':
				case '[object Set]':
					res = (data_1.size == data_2.size);
					break;
				default:
					throw new Error('...');
					break;
			}
			return res;
		}
		//------------------
		_compareObject() {
			// debugger;
			let {
				0: data_1,
				1: data_2,
			} = this.$data;

			let {
				0: type_1,
				1: type_2,
			} = this.$type;

			let res;
			switch (type_1) {
				case '[object Symbol]':
					data_1 = data_1.toString();
					data_2 = data_2.toString();
					res = (data_1 == data_2);
					break;
				default:
					data_1 = JSON.stringify(data_1);
					data_2 = JSON.stringify(data_2);
					res = (data_1 == data_2);
					break;
			}
			return res;
		}
		//------------------
		_toString(data) {
			return Object.prototype.toString.call(data);
		}
		//------------------
		_checkChilds() {
			// debugger;
			let {
				0: data_1,
				1: data_2,
			} = this.$data;

			let {
				0: type_1,
				1: type_2,
			} = this.$type;

			let $childs = [];

			switch (type_1) {
				case '[object Object]{}':
					for (let key in data_1) {
						$childs.push({
							0: data_1[key],
							1: data_2[key],
						});
					}
					break;
				case '[object Array]':
					for (let i = 0; data_1 < data_1.length; i++) {
						$childs.push({
							0: data_1[i],
							1: data_2[i],
						});
					}
					break
				case '[object Map]': {
					let keys = [];
					let values = []
					for (const [key, value] of data_1) {
						keys.push({
							0: key,
						});
						values.push({
							0: value
						});
					}
					let i = 0;
					for (const [key, value] of data_2) {
						keys[i]['1'] = key;
						values[i]['1'] = value;
						i++;
					}
					$childs = keys.concat(values);
				}
				break;
				case '[object Set]': {
					let d_1 = Array.from(data_1);
					let d_2 = Array.from(data_2);

					for (let i = 0; i < d_1.length; i++) {
						$childs.push({
							0: d_1[i],
							1: d_2[i],
						});
					}
				}
				break;
				default:
					throw new Error('...');
					break;
			} // switch

			this.$childs = $childs;
		}
	}
}

//------------------------------------------------------------------------------
{
	$extend.$copyValue = copyValue;
	$extend.copyValue = copyValue;
	//------------------
	//
	// 複製 data 的值
	function copyValue(data) {
		debugger;
		let checkList = [];
		checkList.push(new Item(data, null, null));

		let i = 0;
		while (i < checkList.length) {
			debugger;
			let j = i++;

			let item = checkList[j];

			// here
			let childs = item.getChilds();

			if (Array.isArray(childs)) {
				childs.forEach((item) => {
					checkList.push(item);
				});
			}
		} // while
		//-------------
		// console.dir(checkList);
		// debugger;
		let item;
		while (checkList.length) {
			// debugger;
			item = checkList.pop();
			if (!item.hasParent()) {
				break;
			}
			item.callParent();
		} // while

		let clone = item.clone;
		return clone;
	};
	//-----------------------
	class Item {
		$type;
		// $checkList;
		$key;
		$parent;
		$childs;
		// $index;
		//-------------
		// 原始值
		$value;
		$clone;

		// 數據是否能被 clone
		$canClone = false;
		//-----------------------
		get clone() {
			let res = (this.$clone != null) ? this.$clone : this.$value;
			return res;
		}
		//-----------------------
		constructor(data, parent = null, key = null) {
			debugger;

			this.$value = data;

			if (parent != null) {
				this.$parent = parent;
			}
			if (key != null) {
				this.$key = key;
			}
			this._checkType();

			this._cloneData();
		}
		//-----------------------
		// 檢查是否是容許的數據類型
		_checkType() {
			debugger;
			let $value = this.$value;
			let type = this.$type = $toString($value);

			switch (type) {
				case '[object Null]':
				case '[object Undefined]':
				case "[object String]":
				case "[object Number]":
				case "[object Boolean]":
					this.$canClone = false;
					break;
				case "[object Object]":
					if (!$bb.$isPlainObject(this.$value)) {
						throw new Error('no support');
					}
				case '[object Array]':
				case '[object Map]':
				case '[object Set]':
					this.$canClone = true;
					break;
				case "[object Function]":
				case "[object Symbol]":
				default:
					throw new Error(`no support type(${type})`);
					break;
			}
		}
		//-----------------------
		_checkType_1() {
			this.$type = Object.prototype.toString.call(data);

			switch (this.$type) {
				case '[object Object]':

					break;
				case '[object Array]':
				case '[object Map]':
				case '[object Set]':
				default:
					throw new Error(`no support type(${this.$type})`);
					break;
			} // switch
		}
		//-----------------------
		_cloneData() {
			// isObject

			if (!this.$canClone) {
				return;
			}
			//-------------
			// 針對不同 type 作出 clone 的方法
			// 確定型別是否能被 clone
			switch (this.$type) {
				case '[object Object]':
					this.$clone = {};
					break;
				case '[object Array]':
					this.$clone = [];
					this.$clone.length = this.$value.length;
					break;
				case '[object Map]':
					this.$clone = new Map();
					break;
				case '[object Set]':
					this.$clone = new Set();
					break;
				default:
					break;
			} // switch
		}
		//-----------------------
		_checkCilds() {
			debugger;

			let $childs = this.$childs = [];
			const $data = this.$value;

			switch (this.$type) {
				case '[object Object]':
					for (let key in $data) {
						let value = $data[key];
						let item = new Item(value, this, key);
						$childs.push(item);
					}
					break;
				case '[object Array]':
					for (var i = 0; i < $data.length; i++) {
						let value = $data[i];
						let item = new Item(value, this, i);
						$childs.push(item);
					}
					break;
				case '[object Map]':
					// case '[object WeakMap]':
					for (let [key, value] of $data) {
						// debugger;

						let key_1;
						if (key != null && typeof key == 'object') {
							// here
							// here
							key_1 = $bb.$copyValue(key);
						} else {
							key_1 = key;
						}
						//------------------
						debugger;
						let item = new Item(value, this, key_1);
						$childs.push(item);
					}
					$childs.reverse();
					break;
				case '[object Set]':
					for (let value of $data) {
						let item = new Item(value, this);
						$childs.push(item);
					}
					$childs.reverse();
					break;
				default:
					this.$childs = undefined;
					break;
			}
		}
		//-----------------------
		hasParent() {
			let res = (this.$parent != null);
			return res;
		}
		//-----------------------
		callParent() {
			// debugger;

			let parent = this.$parent;
			let value = this.clone;
			parent.setValue(this.$key, value);
		}
		//-----------------------
		// call by child
		setValue(key, value) {
			debugger;
			let $data = this.$clone;

			switch (this.$type) {
				case '[object Object]':
				case '[object Array]':
					$data[key] = value;
					break;
				case '[object Map]':
					$data.set(key, value);
					break;
				case '[object Set]':
					$data.add(value);
					break;
				default:
					break;
			}
		}
		//-----------------------
		getChilds() {
			this._checkCilds();
			return this.$childs;
		}
	} // class

	function $toString(data) {
		return Object.prototype.toString.call(data);
	}
}
//------------------------------------------------------------------------------
export function handle(bb) {
	$bb = bb;

	for (let name in $extend) {
		if (name in $bb) {
			throw new Error(`${name} has exists`);
		}
		$bb[name] = $extend[name];
	}
	return $extend;
};
