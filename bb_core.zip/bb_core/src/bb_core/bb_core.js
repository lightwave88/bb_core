// 工具集
const $bb = {};
//-----------------------
// 建構 $bb
{
	$bb.global = global;
	//------------------	
	// 可操作的全域變數
	const $globalVars = new Map();
  //------------------
	// 可操作的全域變數
	function global(name, value) {

		switch (argument.length) {
			case 0:
				return new Map($globalVars);
				break;
			case 1:
				return $globalVars.has(name) ? $globalVars.get(name) : undefined;
				break;
			case 2:
			default:
				$globalVars.set(name, value);
				break;
		}
	}
}
//-----------------------
{
	$bb.import = function (fun) {
		fun($bb);
	};
}
//-----------------------
export {
	$bb
};
