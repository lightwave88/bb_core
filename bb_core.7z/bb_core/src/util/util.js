let $bb;

const $extend = {};

$extend.functionId = function(fun, init = true) {
	const functionIdAttrName = $bb.$config('functionIdAttrName');
	if (fun[functionIdAttrName] != null) {
		return fun[functionIdAttrName];
	}
	if (!init) {
		return null;
	}
	let id = $bb.getUid(functionIdAttrName);
	fun[functionIdAttrName] = id;
	return id;
};
//----------------------------
export function handle(bb) {
	$bb = bb;
	const {
		util
	} = bb;

	for (let name in $extend) {
		if (util[name] != null) {
			throw new Error(`bb.util.${name} exists`);
		}
		util[name] = $extend[name];
	}
}
