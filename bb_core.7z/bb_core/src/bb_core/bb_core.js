
// 工具集
const $bb = function () { };

// 可操作的全域變數
const $globalVar = new Map();

// 建構 $bb
const extendList = {

  // 可操作的全域變數
  $globalVar() {
    return $globalVar;
  },
};
Object.assign($bb, extendList);

export { $bb };
